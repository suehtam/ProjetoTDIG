import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { toggleTodo, deleteTodo, editTodo } from "../redux/todoSlice";

export default function TodoItem({ todo }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(todo.text);
  const dispatch = useDispatch();

  const handleEdit = () => {
    if (editing && value.trim()) {
      dispatch(editTodo({ id: todo.id, text: value }));
    }
    setEditing(!editing);
  };

  return (
    <li style={{
      display: "flex", justifyContent: "space-between", alignItems: "center",
      padding: "6px 0", borderBottom: "1px solid #eee"
    }}>
      <div style={{ display: "flex", alignItems: "center" }}>
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => dispatch(toggleTodo(todo.id))}
          style={{ marginRight: "8px" }}
        />
        {editing ? (
          <input
            value={value}
            onChange={e => setValue(e.target.value)}
            style={{ padding: "4px" }}
          />
        ) : (
          <span style={{ textDecoration: todo.completed ? "line-through" : "none" }}>
            {todo.text}
          </span>
        )}
      </div>
      <div>
        <button onClick={handleEdit} style={{ marginRight: "8px" }}>
          {editing ? "Salvar" : "Editar"}
        </button>
        <button onClick={() => dispatch(deleteTodo(todo.id))}>Excluir</button>
      </div>
    </li>
  );
}
