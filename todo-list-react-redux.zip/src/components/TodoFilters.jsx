import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { setFilter } from "../redux/todoSlice";

export default function TodoFilters() {
  const dispatch = useDispatch();
  const { filter } = useSelector(state => state.todos);

  const filters = [
    { label: "Todas", value: "all" },
    { label: "Concluídas", value: "completed" },
    { label: "Pendentes", value: "pending" }
  ];

  return (
    <div style={{ marginTop: "1rem", textAlign: "center" }}>
      {filters.map(f => (
        <button
          key={f.value}
          onClick={() => dispatch(setFilter(f.value))}
          style={{
            margin: "0 4px", padding: "6px 10px",
            backgroundColor: filter === f.value ? "#007bff" : "#ccc",
            color: filter === f.value ? "white" : "black",
            border: "none", borderRadius: "4px"
          }}
        >
          {f.label}
        </button>
      ))}
    </div>
  );
}
