import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTodo } from "../redux/todoSlice";
import TodoItem from "./TodoItem";

export default function TodoList() {
  const [text, setText] = useState("");
  const dispatch = useDispatch();
  const { todos, filter } = useSelector(state => state.todos);

  const filteredTodos = todos.filter(todo => {
    if (filter === "completed") return todo.completed;
    if (filter === "pending") return !todo.completed;
    return true;
  });

  const handleSubmit = e => {
    e.preventDefault();
    if (text.trim()) {
      dispatch(addTodo(text));
      setText("");
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit} style={{ display: "flex", marginBottom: "1rem" }}>
        <input
          type="text"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Adicionar tarefa..."
          style={{ flexGrow: 1, padding: "8px" }}
        />
        <button type="submit" style={{ padding: "8px 12px" }}>Adicionar</button>
      </form>
      <ul style={{ listStyle: "none", padding: 0 }}>
        {filteredTodos.map(todo => (
          <TodoItem key={todo.id} todo={todo} />
        ))}
      </ul>
    </div>
  );
}
