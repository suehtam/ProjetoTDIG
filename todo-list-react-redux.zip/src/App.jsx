import React from "react";
import TodoList from "./components/TodoList";
import TodoFilters from "./components/TodoFilters";

export default function App() {
  return (
    <div style={{
      maxWidth: "600px", margin: "0 auto", padding: "20px",
      backgroundColor: "white", borderRadius: "8px", boxShadow: "0 2px 6px #ccc"
    }}>
      <h1 style={{ textAlign: "center" }}>Lista de Tarefas</h1>
      <TodoList />
      <TodoFilters />
    </div>
  );
}
